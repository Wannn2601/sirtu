"use client"

import { useEffect, useMemo, useState } from "react"
import { motion } from "framer-motion"
import { firestoreService } from "../../services/firebase"

// Utilities
const months = [
  { value: "all", label: "Keseluruhan" },
  { value: "01", label: "Januari" },
  { value: "02", label: "Februari" },
  { value: "03", label: "Maret" },
  { value: "04", label: "April" },
  { value: "05", label: "Mei" },
  { value: "06", label: "Juni" },
  { value: "07", label: "Juli" },
  { value: "08", label: "Agustus" },
  { value: "09", label: "September" },
  { value: "10", label: "Oktober" },
  { value: "11", label: "November" },
  { value: "12", label: "Desember" },
]

const romanMonths = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"]

const pad2 = (n) => String(n).padStart(2, "0")
const formatDate = (d) => {
  if (!d) return "-"
  const dt = new Date(d)
  if (Number.isNaN(dt.getTime())) return "-"
  return `${pad2(dt.getDate())}/${pad2(dt.getMonth() + 1)}/${dt.getFullYear()}`
}

export default function EArsipPage() {
  // Wilayah (from users collection)
  const [users, setUsers] = useState([])
  const [currentUser, setCurrentUser] = useState(null)

  // Data arsip (ambil dari permohonanSurat yang sudah diterima/selesai)
  const [permohonan, setPermohonan] = useState([])
  const [loading, setLoading] = useState(true)

  // Filters
  const currentYear = new Date().getFullYear()
  const [year, setYear] = useState(currentYear)
  const [month, setMonth] = useState("all")
  const [pageSize, setPageSize] = useState(25)
  const [query, setQuery] = useState("")
  const [page, setPage] = useState(1)

  // Derived wilayah header text
  const wilayah = useMemo(() => {
    if (!currentUser) return { rt: "-", rw: "-", kelurahan: "-", kota: "-" }
    const u = currentUser
    return {
      rt: u.RT || u.rt || "-",
      rw: u.RW || u.rw || "-",
      kelurahan: u.Kelurahan || u.kelurahan || "-",
      kota: u.kabupaten_kota || u.kota || "-",
    }
  }, [currentUser])

  // Load users + resolve current logged in user
  useEffect(() => {
    let mounted = true
    ;(async () => {
      try {
        const allUsers = await firestoreService.getAll("users")
        if (!mounted) return
        setUsers(allUsers || [])

        // Try to resolve by localStorage id
        const lsUser =
          JSON.parse(localStorage.getItem("user")) ||
          JSON.parse(localStorage.getItem("authUser")) ||
          JSON.parse(localStorage.getItem("currentUser")) ||
          null

        const uid = lsUser?.id || lsUser?.uid || lsUser?.userId || lsUser?.user?.uid || null

        let found = null
        if (uid) {
          found = allUsers.find((u) => u.id === uid || u.uid === uid)
        }
        if (!found) {
          // fallback: a user that has wilayah and acts as client
          found =
            allUsers.find((u) => (u.RT || u.rt) && (u.RW || u.rw)) ||
            allUsers.find((u) => (u.role || u.level) === "client") ||
            allUsers.find((u) => (u.role || u.level) === "superadmin") ||
            allUsers[0]
        }
        setCurrentUser(found || null)
      } catch (e) {
        console.log("[v0] Load users error:", e)
      }
    })()
    return () => {
      mounted = false
    }
  }, [])

  // Load permohonanSurat data (arsip) scoped by wilayah
  useEffect(() => {
    const mounted = true
    ;(async () => {
      if (!currentUser) return
      setLoading(true)
      try {
        const rows = await firestoreService.getAll("permohonanSurat")
        const { rt, rw, kelurahan, kota } = wilayah

        // only accepted/selesai become arsip
        const filtered = (rows || []).filter((r) => {
          const w = {
            rt: r.RT || r.rt || "",
            rw: r.RW || r.rw || "",
            kelurahan: r.Kelurahan || r.kelurahan || "",
            kota: r.kabupaten_kota || r.kota || "",
          }
          const st = (r.status || "").toLowerCase()
          const isArsip = st === "diterima" || st === "selesai" || st === "approved"
          return (
            isArsip &&
            String(w.rt) === String(rt) &&
            String(w.rw) === String(rw) &&
            String(w.kelurahan).toLowerCase() === String(kelurahan).toLowerCase() &&
            String(w.kota).toLowerCase() === String(kota).toLowerCase()
          )
        })
        if (!mounted) return
        setPermohonan(filtered)
      } catch (e) {
        console.log("[v0] Load permohonanSurat error:", e)
      } finally {
        setLoading(false)
      }
    })()
  }, [currentUser, wilayah])

  const years = useMemo(() => {
    const arr = []
    for (let y = currentYear - 5; y <= currentYear + 1; y++) arr.push(y)
    return arr.reverse()
  }, [currentYear])

  const filteredRows = useMemo(() => {
    let rows = [...permohonan]

    // Filter by year/month on tanggal_terbit or tanggalTerbitSurat or createdAt
    rows = rows.filter((r) => {
      const tglStr = r.tanggal_terbit || r.tanggalTerbitSurat || r.tanggal || r.createdAt || r.created_at || null
      const dt = tglStr ? new Date(tglStr) : null
      const y = dt ? dt.getFullYear() : null
      const m = dt ? pad2(dt.getMonth() + 1) : null
      const byYear = y === year
      const byMonth = month === "all" ? true : m === month
      return byYear && byMonth
    })

    // Search
    const q = query.trim().toLowerCase()
    if (q) {
      rows = rows.filter((r) => {
        const nm = (r.nama_warga || r.nama || r.atas_nama || "").toLowerCase()
        const addr = (r.alamat || "").toLowerCase()
        const jenis = (r.jenis_surat || r.keperluan || "").toLowerCase()
        const ket = (r.keterangan || "").toLowerCase()
        return nm.includes(q) || addr.includes(q) || jenis.includes(q) || ket.includes(q)
      })
    }

    // newest first
    rows.sort((a, b) => {
      const da = new Date(a.tanggal_terbit || a.tanggalTerbitSurat || a.createdAt || 0).getTime() || 0
      const db = new Date(b.tanggal_terbit || b.tanggalTerbitSurat || b.createdAt || 0).getTime() || 0
      return db - da
    })

    return rows
  }, [permohonan, query, year, month])

  const pageCount = Math.max(1, Math.ceil(filteredRows.length / pageSize))
  const pageItems = filteredRows.slice((page - 1) * pageSize, page * pageSize)

  const handleViewPdf = async (row) => {
    // If already stored URL
    if (row.pdfUrl || row.fileUrl) {
      window.open(row.pdfUrl || row.fileUrl, "_blank", "noopener,noreferrer")
      return
    }
    // else generate on the fly
    const { jsPDF } = await import("jspdf")
    const doc = new jsPDF({ unit: "mm", format: "a4" })

    const city = wilayah.kota?.toString().toUpperCase() || "KOTA"
    const kec = (row.kecamatan || row.Kecamatan || currentUser?.kecamatan || "").toString().toUpperCase()
    const kel = wilayah.kelurahan?.toString().toUpperCase() || ""
    const rtRw = `RT ${wilayah.rt} / RW ${wilayah.rw}`

    // Header
    doc.setFont("helvetica", "bold")
    doc.setFontSize(16)
    doc.text(city, 105, 18, { align: "center" })
    doc.setFontSize(12)
    doc.text(`KECAMATAN ${kec}`, 105, 26, { align: "center" })
    doc.text(`KELURAHAN ${kel}`, 105, 32, { align: "center" })
    doc.text(rtRw, 105, 38, { align: "center" })
    doc.line(20, 42, 190, 42)

    // Nomor/Lampiran/Hal
    doc.setFont("helvetica", "normal")
    doc.setFontSize(10)
    const nomor = row.nomor_surat || row.nomorSurat || "-"
    const lampiran = row.jumlah_lampiran ? `${row.jumlah_lampiran} ${row.satuan_lampiran || ""}` : "-"
    const hal = row.jenis_surat || row.keperluan || "Surat Pengantar"

    doc.text(`Nomor   : ${nomor}`, 20, 50)
    doc.text(`Lampiran: ${lampiran}`, 20, 56)
    doc.text(`Hal     : ${hal}`, 20, 62)

    // Tanggal + Tujuan
    const dt = new Date(row.tanggal_terbit || row.tanggalTerbitSurat || new Date())
    doc.text(`${wilayah.kota}, ${formatDate(dt)}`, 140, 50)
    doc.text("Kepada Yth.", 140, 56)
    doc.text(`Kepala Kelurahan ${kel}`, 140, 62)
    doc.text(`Kecamatan ${kec}`, 140, 68)
    doc.text("di", 140, 74)
    doc.setFont("helvetica", "bold")
    doc.text(city, 156, 74)
    doc.setFont("helvetica", "normal")

    // Body
    let y = 86
    doc.text("Bersama ini menerangkan bahwa:", 20, y)
    y += 8

    const lines = [
      ["Nama", row.nama_warga || row.nama || "-"],
      ["Tempat / Tgl. Lahir", `${row.tempat_lahir || "-"}, ${formatDate(row.tgl_lahir)}`],
      ["Kewarganegaraan / Agama", `${row.kewarganegaraan || "-"} / ${row.agama || "-"}`],
      ["Status", row.status_kawin || row.status || "-"],
      ["Pendidikan terakhir", row.pendidikan || "-"],
      ["Pekerjaan", row.pekerjaan || "-"],
      ["Alamat", row.alamat || "-"],
      ["No. NIK", row.nik || row.nik_warga || "-"],
      ["Keperluan", row.jenis_surat || row.keperluan || "-"],
      ["Keterangan lain-lain", row.keterangan || "-"],
    ]
    lines.forEach((item, idx) => {
      doc.text(`${idx + 1}. ${item[0]}`, 20, y)
      doc.text(": ", 70, y)
      doc.text(String(item[1] || "-"), 76, y)
      y += 7
    })

    // Ttd
    y += 6
    doc.text("Demikian untuk menjadikan periksa dan guna seperlunya.", 20, y)
    y += 14
    doc.text("Mengetahui", 20, y)
    doc.text(`Ketua RW ${wilayah.rw}`, 20, y + 6)
    doc.text(`Ketua RT ${wilayah.rt} / RW ${wilayah.rw}`, 140, y + 6)

    // Open
    window.open(doc.output("bloburl"), "_blank", "noopener,noreferrer")
  }

  return (
    <motion.main
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="p-4 md:p-6"
    >
      <div className="max-w-7xl mx-auto space-y-4">
        <header className="space-y-1">
          <h1 className="text-xl md:text-2xl font-semibold text-foreground text-balance">eARSIP SURAT</h1>
          <p className="text-sm text-muted-foreground">
            RT {wilayah.rt} RW {wilayah.rw} Kelurahan {wilayah.kelurahan} - {wilayah.kota}
          </p>
        </header>

        {/* Filters */}
        <section className="bg-card border border-border rounded-lg p-3 md:p-4">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            <div className="flex flex-col gap-1">
              <label className="text-xs text-muted-foreground">Tahun Buku</label>
              <select
                className="h-9 rounded-md border border-input bg-background px-2 text-sm"
                value={year}
                onChange={(e) => {
                  setYear(Number(e.target.value))
                  setPage(1)
                }}
              >
                {years.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-xs text-muted-foreground">Bulan Terbit</label>
              <select
                className="h-9 rounded-md border border-input bg-background px-2 text-sm"
                value={month}
                onChange={(e) => {
                  setMonth(e.target.value)
                  setPage(1)
                }}
              >
                {months.map((m) => (
                  <option key={m.value} value={m.value}>
                    {m.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-xs text-muted-foreground">View</label>
              <select
                className="h-9 rounded-md border border-input bg-background px-2 text-sm"
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value))
                  setPage(1)
                }}
              >
                {[25, 50, 100].map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </div>

            <div className="md:col-span-2 flex flex-col gap-1">
              <label className="text-xs text-muted-foreground">Cari</label>
              <input
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value)
                  setPage(1)
                }}
                placeholder="ketik untuk mencari…"
                className="h-9 rounded-md border border-input bg-background px-3 text-sm"
              />
            </div>
          </div>
        </section>

        {/* Table */}
        <section className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-muted/40 text-foreground">
                <tr className="text-left">
                  <th className="px-3 py-2 font-medium">Tanggal terbit</th>
                  <th className="px-3 py-2 font-medium">Atas Nama</th>
                  <th className="px-3 py-2 font-medium">Alamat</th>
                  <th className="px-3 py-2 font-medium">Jenis Surat</th>
                  <th className="px-3 py-2 font-medium">Keterangan</th>
                  <th className="px-3 py-2 font-medium">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td className="px-3 py-6 text-muted-foreground" colSpan={6}>
                      Memuat data…
                    </td>
                  </tr>
                ) : pageItems.length === 0 ? (
                  <tr>
                    <td className="px-3 py-6 text-muted-foreground" colSpan={6}>
                      Tidak ada arsip untuk filter ini.
                    </td>
                  </tr>
                ) : (
                  pageItems.map((r) => {
                    const tgl = r.tanggal_terbit || r.tanggalTerbitSurat || r.createdAt || r.tanggal
                    return (
                      <tr key={r.id} className="border-t border-border">
                        <td className="px-3 py-2">{formatDate(tgl)}</td>
                        <td className="px-3 py-2">{r.nama_warga || r.nama || r.atas_nama || "-"}</td>
                        <td className="px-3 py-2">{r.alamat || "-"}</td>
                        <td className="px-3 py-2">{r.jenis_surat || r.keperluan || "-"}</td>
                        <td className="px-3 py-2">{r.keterangan || "-"}</td>
                        <td className="px-3 py-2">
                          <button
                            onClick={() => handleViewPdf(r)}
                            className="h-8 rounded-md bg-primary text-primary-foreground px-3 hover:opacity-90"
                          >
                            View
                          </button>
                        </td>
                      </tr>
                    )
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between px-3 py-3 border-t border-border">
            <div className="text-xs text-muted-foreground">
              Halaman {page} dari {pageCount}
            </div>
            <div className="flex items-center gap-1">
              {["<<<", "<<", "<"].map((lab, idx) => (
                <button
                  key={lab}
                  className="h-8 min-w-8 rounded border border-input text-xs px-2"
                  onClick={() => {
                    if (idx === 0) setPage(1)
                    if (idx === 1) setPage(Math.max(1, page - 5))
                    if (idx === 2) setPage(Math.max(1, page - 1))
                  }}
                >
                  {lab}
                </button>
              ))}
              {Array.from({ length: Math.min(5, pageCount) }).map((_, i) => {
                const start = Math.max(1, Math.min(page - 2, pageCount - 4))
                const p = start + i
                return (
                  <button
                    key={p}
                    onClick={() => setPage(p)}
                    className={`h-8 min-w-8 rounded border border-input text-xs px-2 ${p === page ? "bg-accent" : ""}`}
                  >
                    {p}
                  </button>
                )
              })}
              {[">", ">>", ">>>"].map((lab, idx) => (
                <button
                  key={lab}
                  className="h-8 min-w-8 rounded border border-input text-xs px-2"
                  onClick={() => {
                    if (idx === 0) setPage(Math.min(pageCount, page + 1))
                    if (idx === 1) setPage(Math.min(pageCount, page + 5))
                    if (idx === 2) setPage(pageCount)
                  }}
                >
                  {lab}
                </button>
              ))}
            </div>
          </div>
        </section>
      </div>
    </motion.main>
  )
}
